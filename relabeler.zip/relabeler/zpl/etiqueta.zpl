^XA
^PW812
^LL0609
^CI28
^FO40,40^A0N,50,50^FDNo. parte: $part_number^FS
^FO40,110^A0N,40,40^FDLote: $lot^FS
^FO40,170^A0N,40,40^FDCantidad: $quantity^FS
^FO40,230^A0N,40,40^FDProveedor: $supplier^FS
^FO40,290^A0N,40,40^FDFecha: $date_code^FS
^FO40,360^BY3^BCN,120,Y,N,N^FD$part_number^FS
^XZ
