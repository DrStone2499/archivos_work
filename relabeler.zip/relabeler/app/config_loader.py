import json
import os
import shutil

from app.paths import app_dir, resource

_cache = None


def load(force: bool = False) -> dict:
    """Lee config.json de junto al ejecutable. Si no existe, copia el de fabrica."""
    global _cache
    if _cache is not None and not force:
        return _cache

    user_path = os.path.join(app_dir(), "config.json")
    if not os.path.exists(user_path):
        shutil.copyfile(resource("config.json"), user_path)

    with open(user_path, "r", encoding="utf-8") as fh:
        _cache = json.load(fh)
    return _cache


def save(data: dict) -> None:
    global _cache
    with open(os.path.join(app_dir(), "config.json"), "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)
    _cache = data
