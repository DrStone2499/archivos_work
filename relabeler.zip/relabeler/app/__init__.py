from flask import Flask

from app.paths import resource


def create_app(pipeline):
    app = Flask(
        __name__,
        template_folder=resource("templates"),
        static_folder=resource("static"),
    )
    app.config["PIPELINE"] = pipeline

    from app.routes import bp
    app.register_blueprint(bp)
    return app
