"""Resolucion de rutas que funciona igual en desarrollo y en el .exe de PyInstaller."""
import os
import sys


def bundle_dir() -> str:
    """Recursos de solo lectura (templates, static, modelo, zpl)."""
    if getattr(sys, "frozen", False):
        return sys._MEIPASS
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def app_dir() -> str:
    """Carpeta escribible junto al ejecutable (config.json, data/, logs)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def resource(*parts) -> str:
    return os.path.join(bundle_dir(), *parts)


def writable(*parts) -> str:
    path = os.path.join(app_dir(), *parts)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path
