# Re-etiquetado de cajas — app local (Python + Flask + pywebview + Ultralytics)

## Estructura

```
main.py              arranque: Flask en hilo + ventana pywebview
config.json          lo que el tecnico puede editar (IPs, camara, umbrales)
settings.py          constantes de codigo + definicion de CAMPOS del formulario
app/
  paths.py           rutas que funcionan igual en dev y dentro del .exe (sys._MEIPASS)
  config_loader.py   copia config.json junto al .exe la primera vez
  routes.py          rutas Flask + SSE
resources/
  camera_lib.py      UsbCamera / BaslerCamera / FileCamera + hilo de captura
  detector_lib.py    YOLO (ultralytics) + asociacion etiqueta -> caja
  ocr_lib.py         preproceso, deskew, OCR y extraccion de campos por regex
  printer_lib.py     ZPL por socket 9100
  storage_lib.py     historial en SQLite
  pipeline.py        hilo unico: captura -> deteccion -> OCR condicionado
templates/ static/   UI
zpl/etiqueta.zpl     plantilla de la etiqueta nueva ($part_number, $lot, ...)
models/              aqui va boxes_labels.pt
```

## Flujo

1. El hilo de captura siempre tiene el ultimo frame (nadie espera IO).
2. El pipeline detecta `caja` y `etiqueta` en cada frame. Cada etiqueta se
   asigna a la caja que la contiene; la caja mas grande con etiqueta es la
   "de interes".
3. El OCR **no** corre en cada frame. Corre cuando la caja lleva N frames
   quieta (`pipeline.stable_frames`) o cuando el operador toca "Leer ahora".
   Eso es lo que mantiene la UI fluida en CPU.
4. Los campos se autocompletan con los regex de `settings.FIELDS`. Los de
   confianza baja se marcan en ambar para que el operador los verifique.
5. "Imprimir etiqueta nueva" valida obligatorios, renderiza el ZPL, lo manda
   a la impresora y guarda el registro en SQLite.

## Adaptar a tu planta

- **Campos**: edita `settings.FIELDS`. Cada campo es clave, etiqueta visible,
  regex y si es obligatorio. El HTML y el JS se generan a partir de esa lista.
- **Plantilla de etiqueta**: `zpl/etiqueta.zpl`, con `$clave` por cada campo.
- **Camara**: `config.json > camera.backend` = `usb`, `basler` o `file`.
  `file` sirve para probar la UI con un video o una foto, sin hardware.

## Modelo YOLO

Dos clases: `caja` y `etiqueta`. Con 300–500 imagenes tomadas desde la posicion
real de la camara (misma altura, mismo lente, mismas luces) suele bastar.

```bash
yolo detect train data=dataset.yaml model=yolo11n.pt imgsz=960 epochs=120 batch=8
```

Copia el `best.pt` a `models/boxes_labels.pt`.

Consejo: entrena con la caja completa aunque quede recortada en el borde, y
etiqueta tambien las etiquetas arrugadas o con reflejo — es el caso que mas
falla en produccion.

## Correr en desarrollo

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

## Compilar

```bash
pyinstaller build.spec --noconfirm
```

**Advertencia de tamano**: ultralytics arrastra torch, y el ejecutable sale de
1.5–2.5 GB. Si eso es problema en las maquinas de piso, exporta el modelo a
ONNX (`yolo export model=best.pt format=onnx`) y cambia `detector_lib.py` a
`onnxruntime`; el paquete baja a ~300 MB. El resto del codigo no cambia.

EasyOCR tambien descarga pesos la primera vez: hazlo una vez en la maquina de
build y copia la carpeta `~/.EasyOCR` dentro del bundle, o el .exe fallara en
una PC sin internet.
