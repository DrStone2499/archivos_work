"""Librerias de hardware y proceso."""
