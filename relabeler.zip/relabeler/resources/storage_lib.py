"""Historial de re-etiquetados en SQLite."""
import json
import sqlite3
from datetime import datetime

import settings
from app.paths import writable

_SCHEMA = """
CREATE TABLE IF NOT EXISTS relabels (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at  TEXT NOT NULL,
    operator    TEXT,
    ocr_text    TEXT,
    fields_json TEXT NOT NULL,
    crop_path   TEXT,
    printed     INTEGER NOT NULL DEFAULT 0
);
"""


def _connect():
    conn = sqlite3.connect(writable(settings.DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def init():
    with _connect() as conn:
        conn.execute(_SCHEMA)


def save_relabel(fields: dict, ocr_text: str, crop_path: str = "",
                 operator: str = "", printed: bool = False) -> int:
    with _connect() as conn:
        cur = conn.execute(
            "INSERT INTO relabels (created_at, operator, ocr_text, fields_json, crop_path, printed)"
            " VALUES (?,?,?,?,?,?)",
            (datetime.now().isoformat(timespec="seconds"), operator, ocr_text,
             json.dumps(fields, ensure_ascii=False), crop_path, int(printed)),
        )
        return cur.lastrowid


def recent(limit: int = 25):
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, created_at, fields_json, printed FROM relabels ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [{"id": r["id"], "created_at": r["created_at"], "printed": bool(r["printed"]),
             "fields": json.loads(r["fields_json"])} for r in rows]
