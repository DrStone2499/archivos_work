"""Envio de la etiqueta nueva a la impresora ZPL (Zebra) por socket 9100."""
import socket
from string import Template


class PrinterError(RuntimeError):
    pass


def render_zpl(template_path: str, values: dict) -> str:
    with open(template_path, "r", encoding="utf-8") as fh:
        template = Template(fh.read())
    return template.safe_substitute({k: str(v) for k, v in values.items()})


def send(zpl: str, host: str, port: int = 9100, timeout: float = 5.0) -> None:
    try:
        with socket.create_connection((host, port), timeout=timeout) as sock:
            sock.sendall(zpl.encode("utf-8"))
    except OSError as exc:
        raise PrinterError(f"No se pudo enviar a {host}:{port} — {exc}") from exc
